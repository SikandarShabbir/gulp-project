var name = "Sikandar";

document.write('Hello Mr.'+name+'!');